function logout(){
    window.location.replace("login.html");
}